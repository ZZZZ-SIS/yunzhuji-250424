from playwright.sync_api import sync_playwright
from concurrent.futures import ThreadPoolExecutor, as_completed
from queue import Queue
from threading import Lock
import random
import time
import re
from tqdm import tqdm
from GoogleAuth import GoogleSheetsClient
from apscheduler.schedulers.blocking import BlockingScheduler
from apscheduler.triggers.cron import CronTrigger
from datetime import datetime,timezone
from zoneinfo import ZoneInfo
import sys
from multiprocessing import Process
from loguru import logger
from apscheduler.schedulers.blocking import BlockingScheduler
from apscheduler.triggers.cron import CronTrigger
import os
from bs4 import BeautifulSoup
import json
from playwright_stealth import stealth_sync


SPREADSHEET_ID = '1_TIzVlIItNMLMtFTkZpDWkSrhjevwJZdkm4IPTMkeQA'
SHEET_NAME = 'sheet_1'
GOOGLE_AUTH_FILE = './google_service_account.json'

class PostInfo:
    def __init__(self):
        self.browser = sync_playwright().start().chromium.launch(headless=True,
                                                            args=[
                                                                "--disable-blink-features=AutomationControlled",
                                                                "--disable-infobars",
                                                                "--start-maximized",
                                                                "--no-sandbox",
                                                                "--disable-setuid-sandbox",
                                                                "--disable-dev-shm-usage",
                                                                "--disable-extensions",
                                                                "--disable-gpu",
                                                            ]
                                                            )
        self.context = self.browser.new_context(
            # storage_state='./auth.json',
            user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36",
            locale="en-US",
            viewport={"width": 1280, "height": 800},
            java_script_enabled=True
        )
        # 忽略一些检测特征
        self.context.add_init_script("""
            Object.defineProperty(navigator, 'webdriver', { get: () => undefined });
        """)

        self.page = self.browser.new_page()

    def parse_abbreviated_number(self, text: str, keyword: str = None) -> int | None:
        """
        解析文本中的数字，支持：
        - 英文单位：'3.2K', '1.5M', '7B'
        - 中文简繁体单位：'1.2万', '3千', '2億'
        - 千分位：'1,234'
        - 可选关键词过滤
        """
        if not text:
            return None

        logger.info(f"解析文本：{text}")

        if keyword and keyword.lower() not in text.lower():
            return None

        # 匹配数字+单位（支持中英文）
        match = re.search(r"([\d,.]+)\s*([kKmMbB萬万千亿億]?)", text)
        if not match:
            return None

        num_str, unit = match.groups()
        num_str = num_str.replace(",", "").strip()

        try:
            num = float(num_str)
            multiplier = {
                '': 1,
                'k': 1_000,
                'm': 1_000_000,
                'b': 1_000_000_000,
                '千': 1_000,
                '萬': 10_000, '万': 10_000,
                '億': 100_000_000, '亿': 100_000_000,
            }.get(unit.lower() if unit.lower() in 'kmb' else unit, 1)

            return int(num * multiplier)
        except ValueError:
            return None

    def extract_number_by_selector(self, page, selector: str, keyword: str = None):
        """
        从页面中提取数字，支持关键词过滤和单位缩写（如 K、M、B）
        """
        try:
            page.wait_for_selector(selector, timeout=15 * 1000)
            elements = page.locator(selector)
            count = elements.count()

            for i in range(count):
                text = elements.nth(i).inner_text().strip()
                number = self.parse_abbreviated_number(text, keyword)
                if number is not None:
                    return number

        except Exception as e:
            logger.warning(f"⚠️ 提取失败 selector={selector} keyword={keyword}: {e}")

        return '获取失败'

    def behave_like_human(self, page):
        time.sleep(random.uniform(1.5, 3.5))
        page.mouse.wheel(0, random.randint(200, 1000))  # 模拟滚动
        time.sleep(random.uniform(0.5, 1.2))

    def extract_reaction_count_from_json(self, page):
        """
        从 <script type="application/json"> 中提取 reaction_count
        """
        try:
            html = page.content()
            soup = BeautifulSoup(html, 'html.parser')
            scripts = soup.find_all('script', {'type': 'application/json'})

            for script in scripts:
                try:
                    data = json.loads(script.string)
                    data_str = json.dumps(data)

                    if 'comet_ufi_summary_and_actions_renderer' not in data_str:
                        continue

                    # 改进后的正则表达式，使用非贪婪匹配处理跨行和空格问题
                    pattern = r'"comet_ufi_summary_and_actions_renderer":\s*{[\s\S]*?"reaction_count":\s*{[\s\S]*?"count":\s*(\d+)'
                    # 查找所有匹配项
                    matches = re.findall(pattern, data_str, re.DOTALL)

                    # 输出匹配结果
                    if matches:
                        for match in matches:
                            logger.info(f"Found count: {match}")
                    else:
                        logger.info("No matches found")

                    return int(matches[0])
                except Exception as e:
                    continue
            return "获取失败"
        except Exception as e:
            logger.warning(f"⚠️ 提取失败:")
        return "获取失败"

    def extract_post_info(self, post_url):
        try:
            page = self.page
            stealth_sync(page)
            logger.info("🌐 正在打开页面...")
            self.behave_like_human(page)
            page.goto(post_url, timeout=60000)
            # 点赞数
            # like_num = self.extract_number_by_selector(page, 'span.x1e558r4')
            like_num = self .extract_reaction_count_from_json(page)

            return like_num

        except Exception as e:
            logger.warning(f"⚠️ 提取失败 url={post_url}: {e}")
            return '失败'

    def __del__(self):
        self.browser.close()

def replace_permalink_and_pending_posts(url):
    # 使用字符串的 replace 方法来替换
    url = url.replace('/permalink/', '/posts/').replace('/pending_posts/', '/posts/')
    return url

def extract_page_url(url: str):
    match = re.search(r'story_fbid=([^&]+).*?id=(\d+)', url)
    if match:
        story_fbid, user_id = match.groups()
        page_post_url = f'https://www.facebook.com/{user_id}/posts/{story_fbid}'
        return page_post_url
    return url

def get_hanle_url():
    google_client = GoogleSheetsClient(GOOGLE_AUTH_FILE)
    sheet = google_client.get_worksheet(SPREADSHEET_ID, SHEET_NAME)
    values = sheet.get_values('A2:A')
    return list({row[0] for row in values if row and row[0] and str(row[0]).strip()})

def write_to_sheet(output):
    google_client = GoogleSheetsClient(GOOGLE_AUTH_FILE)
    sheet = google_client.get_worksheet(SPREADSHEET_ID, SHEET_NAME)
    range = "B2:E"
    # 按照点赞数（第2列）从大到小排序
    output.sort(
        key=lambda x: (not isinstance(x[1], (int, float)), -x[1] if isinstance(x[1], (int, float)) else float('inf'))
    )

    sheet.batch_clear([range])
    sheet.update(output, range)

# 主函数
def main():
    urls = get_hanle_url()

    url_queue = Queue()
    for url in urls:
        url_queue.put(url)

    lock = Lock()
    pbar = tqdm(total=url_queue.qsize(), desc="抓取进度")

    output = list()
    # 获取当前 UTC 时间
    beijing_time = datetime.now(timezone.utc).astimezone(ZoneInfo("Asia/Shanghai"))
    formatted = beijing_time.strftime("%Y-%m-%d %H:%M:%S")

    faile_count = [0]

    def worker(thread_id):
        post_info = PostInfo()
        while True:
            with lock:
                if url_queue.empty():
                    break
                raw_url = url_queue.get()

            try:
                url = replace_permalink_and_pending_posts(raw_url)
                url = extract_page_url(url)

                result = post_info.extract_post_info(url)
                # 如果失败再尝试一次
                if result == '获取失败':
                    result = post_info.extract_post_info(url)

                with lock:
                    if result == '获取失败':
                        faile_count[0] = faile_count[0] + 1
                    output.append([raw_url, result, '', formatted])
                logger.info(
                    f"[Thread-{thread_id}] ✅ {raw_url}\n"
                    f"    👍 点赞: {result}"
                )
            except Exception as e:
                logger.exception(f"[Thread-{thread_id}] ❌ 抓取失败: {url}\n    错误信息: {e}")
            finally:
                with lock:
                    pbar.update(1)

    with ThreadPoolExecutor(max_workers=36) as executor:
        for i in range(36):
            executor.submit(worker, i)

    pbar.close()

    write_to_sheet(output)
    # 计算百分比
    failed_percentage = (faile_count[0] / len(urls)) * 100

    # 打印结果
    logger.info(f"It's Over!!! | 失败任务: {faile_count[0]}/{len(urls)} ({failed_percentage:.2f}%)")

def run_main():
    # 子进程也配置日志
    logger.remove()
    logger.add(sys.stdout, level="INFO", enqueue=True, backtrace=True, diagnose=True)

    # 可选：每个进程独立日志文件
    timestamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    logger.add(f"logs/{os.getpid()}_{timestamp}.log", rotation="1 day", retention="7 days", encoding="utf-8")

    logger.info(f"🚀 子进程 PID={os.getpid()} 启动任务")

    # === 你的主任务逻辑 ===
    main()

def timer_task():
    scheduler = BlockingScheduler()

    scheduler.add_job(
        lambda: Process(target=run_main).start(),  # 每次运行一个新进程
        CronTrigger(minute='0,30'),  # 每半小时
        id="half_hour_job",
        name="Run every 30 minutes",
        replace_existing=True
    )

    logger.remove()
    logger.add(sys.stdout, level="INFO")

    logger.info("⏰ 调度器已启动，每 30 分钟运行一次（全天不间断）...")
    try:
        scheduler.start()
    except (KeyboardInterrupt, SystemExit):
        logger.info("🛑 程序已退出。")


if __name__ == "__main__":
    run_main()
    timer_task()

