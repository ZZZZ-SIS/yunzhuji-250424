import gspread
import os
import threading
from glob import glob
from google.oauth2.service_account import Credentials

class GoogleSheetsClient:
    """
    Google Sheets API 客户端封装。
    允许使用服务账户 JSON 文件进行身份验证，并提供访问 Google Sheets 的方法。
    """

    def get_limit(self):
        creds = Credentials.from_service_account_file(
            "./personLoadData.json", scopes=self.scopes
        )
        gspread.authorize(creds).open_by_key()

    def __init__(self, service_account_path: str, scopes=None):
        """
        初始化 Google Sheets 客户端。

        :param service_account_path: Google 服务账户 JSON 文件路径。
        :param scopes: API 作用域（默认支持 Google Sheets 读写）。
        """
        if scopes is None:
            scopes = ["https://www.googleapis.com/auth/spreadsheets"]

        self.service_account_path = service_account_path
        self.scopes = scopes
        self.client = self._authenticate()
        # 获取文件名称
        self.name = os.path.splitext(os.path.basename(self.service_account_path))[0]

    def _authenticate(self):
        """
        使用 Google 服务账户进行 OAuth 认证，并返回 gspread 客户端。
        """
        if not os.path.exists(self.service_account_path):
            raise FileNotFoundError(
                f"找不到服务账户 JSON 文件: {self.service_account_path}"
            )

        creds = Credentials.from_service_account_file(
            self.service_account_path, scopes=self.scopes
        )
        return gspread.authorize(creds)

    def creds(self):
        if not os.path.exists(self.service_account_path):
            raise FileNotFoundError(
                f"找不到服务账户 JSON 文件: {self.service_account_path}"
            )

        creds = Credentials.from_service_account_file(
            self.service_account_path, scopes=self.scopes
        )
        return creds

    def get_worksheet(self, spreadsheet_name: str, sheet_name: str = "Sheet1"):
        """
        获取 Google Sheets 的工作表对象。

        :param spreadsheet_name: Google Sheets 文件名称。
        :param sheet_name: 需要访问的工作表名称（默认 "Sheet1"）。
        :return: gspread.Worksheet 对象。
        """
        try:
            spreadsheet = self.client.open_by_key(spreadsheet_name)
            worksheet = spreadsheet.worksheet(sheet_name)
            return worksheet
        except gspread.exceptions.SpreadsheetNotFound:
            raise ValueError(f"未找到 Google Sheets 文件: {spreadsheet_name}")
        except gspread.exceptions.WorksheetNotFound:
            raise ValueError(f"未找到工作表: {sheet_name}")

    def get_values(self, spreadsheet_id_or_url: str, sheet_name: str = "Sheet1", range_: str = "A1:Z1000"):
        """
        一次性获取工作表指定范围的数据。

        :param spreadsheet_id_or_url: 表格 ID 或 URL。
        :param sheet_name: 工作表名。
        :param range_: 数据范围。
        :return: 二维数组数据。
        """
        full_range = f"{sheet_name}!{range_}"
        try:
            return self.client.values_get(spreadsheet_id_or_url, full_range)["values"]
        except Exception as e:
            raise RuntimeError(f"读取范围 {full_range} 时出错: {e}")

    def get_spreadsheet(self, spreadsheet_name: str):
        try:
            spreadsheet = self.client.open_by_key(spreadsheet_name)
            return spreadsheet
        except gspread.exceptions.SpreadsheetNotFound:
            raise ValueError(f"未找到 Google Sheets 文件: {spreadsheet_name}")
